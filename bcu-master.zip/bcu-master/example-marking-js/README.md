# moocon-marking-service

```
# start in debug mode
DEBUG=moocon-js-marking:* npm start
```